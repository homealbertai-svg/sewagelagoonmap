import { build as esbuild } from "esbuild";
import { build as viteBuild } from "vite";
import { rm, readFile, writeFile } from "node:fs/promises";
import path from "node:path";

// server deps to bundle to reduce openat(2) syscalls
const allowlist = [
  "@google/generative-ai",
  "axios",
  "bcryptjs",
  "cors",
  "date-fns",
  "drizzle-orm",
  "drizzle-zod",
  "express",
  "express-rate-limit",
  "express-session",
  "jsonwebtoken",
  "memorystore",
  "multer",
  "nanoid",
  "nodemailer",
  "openai",
  "passport",
  "passport-local",
  "stripe",
  "uuid",
  "ws",
  "xlsx",
  "zod",
  "zod-validation-error",
];

async function inlineLagoons() {
  const lagoonsPath = path.resolve("/home/user/workspace/lagoons.json");
  const indexPath = path.resolve("dist/public/index.html");
  console.log("inlining lagoons.json into", indexPath);
  const lagoons = await readFile(lagoonsPath, "utf-8");
  const html = await readFile(indexPath, "utf-8");
  const replaced = html.replace(
    /\/\* LAGOONS_DATA_PLACEHOLDER \*\/\s*\[\]/,
    () => lagoons,
  );
  if (replaced === html) {
    console.warn("WARNING: Placeholder not found in index.html — lagoons not inlined");
  }
  await writeFile(indexPath, replaced);
  console.log(`inlined ${(lagoons.length / 1024 / 1024).toFixed(2)} MB of lagoon data`);
}

async function buildAll() {
  await rm("dist", { recursive: true, force: true });

  console.log("building client...");
  await viteBuild();

  console.log("inlining data...");
  await inlineLagoons();

  console.log("building server...");
  const pkg = JSON.parse(await readFile("package.json", "utf-8"));
  const allDeps = [
    ...Object.keys(pkg.dependencies || {}),
    ...Object.keys(pkg.devDependencies || {}),
  ];
  const externals = allDeps.filter((dep) => !allowlist.includes(dep));

  await esbuild({
    entryPoints: ["server/index.ts"],
    platform: "node",
    bundle: true,
    format: "cjs",
    outfile: "dist/index.cjs",
    define: {
      "process.env.NODE_ENV": '"production"',
    },
    minify: true,
    external: externals,
    logLevel: "info",
  });
}

buildAll().catch((err) => {
  console.error(err);
  process.exit(1);
});
