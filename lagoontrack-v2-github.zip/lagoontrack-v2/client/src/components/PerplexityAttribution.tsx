export default function PerplexityAttribution() {
  return (
    <a
      href="https://www.perplexity.ai/computer"
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-3 left-3 z-[1100] text-[10px] uppercase tracking-wider text-muted-foreground/70 hover:text-foreground bg-card/80 backdrop-blur border border-card-border rounded-md px-2 py-1"
      data-testid="link-perplexity-attribution"
    >
      Built with Perplexity Computer
    </a>
  );
}
