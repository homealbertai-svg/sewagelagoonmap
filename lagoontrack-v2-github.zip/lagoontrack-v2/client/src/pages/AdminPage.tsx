import { useEffect, useMemo, useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/App";
import { apiRequest } from "@/lib/queryClient";
import { ALL_STATES, STATE_NAMES } from "@/lib/states";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue
} from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { ArrowLeft, Plus, Pencil, Trash2, LogOut } from "lucide-react";
import PerplexityAttribution from "@/components/PerplexityAttribution";

const DISTRIBUTORS = ["CC Lynch", "GeoTech", "Eijkelkamp USA"];

type AdminUser = {
  id: number;
  username: string;
  role: string;
  distributor: string;
  territories: string; // JSON string
};

type LagoonRecord = {
  id: number;
  facilityName: string;
  approached: string;
  distributor: string;
  note: string;
  updatedBy: string;
  updatedAt: string;
};

export default function AdminPage() {
  const { user, logout } = useAuth();
  const [, navigate] = useLocation();
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [records, setRecords] = useState<LagoonRecord[]>([]);
  const [loading, setLoading] = useState(true);

  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<AdminUser | null>(null);

  // Form fields
  const [fUsername, setFUsername] = useState("");
  const [fPassword, setFPassword] = useState("");
  const [fRole, setFRole] = useState<"admin" | "distributor">("distributor");
  const [fDistributor, setFDistributor] = useState("");
  const [fTerritories, setFTerritories] = useState<string[]>([]);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const refreshAll = async () => {
    setLoading(true);
    try {
      const [u, r] = await Promise.all([
        apiRequest("GET", "/api/users").then(x => x.json()),
        apiRequest("GET", "/api/records").then(x => x.json()),
      ]);
      setUsers(u);
      setRecords(r);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { refreshAll(); }, []);

  const openCreate = () => {
    setEditingUser(null);
    setFUsername("");
    setFPassword("");
    setFRole("distributor");
    setFDistributor("");
    setFTerritories([]);
    setError(null);
    setDialogOpen(true);
  };

  const openEdit = (u: AdminUser) => {
    setEditingUser(u);
    setFUsername(u.username);
    setFPassword("");
    setFRole((u.role as "admin" | "distributor") || "distributor");
    setFDistributor(u.distributor || "");
    try { setFTerritories(JSON.parse(u.territories || "[]")); } catch { setFTerritories([]); }
    setError(null);
    setDialogOpen(true);
  };

  const handleSubmit = async () => {
    setError(null);
    setSaving(true);
    try {
      const payload: any = {
        username: fUsername,
        role: fRole,
        distributor: fRole === "distributor" ? fDistributor : "",
        territories: JSON.stringify(fRole === "distributor" ? fTerritories : []),
      };
      if (fPassword) payload.password = fPassword;

      if (editingUser) {
        await apiRequest("PUT", `/api/users/${editingUser.id}`, payload);
      } else {
        if (!fPassword) {
          setError("Password is required");
          setSaving(false);
          return;
        }
        await apiRequest("POST", "/api/users", payload);
      }
      setDialogOpen(false);
      await refreshAll();
    } catch (e: any) {
      setError(String(e?.message || "Failed to save user"));
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (u: AdminUser) => {
    if (!confirm(`Delete user "${u.username}"?`)) return;
    try {
      await apiRequest("DELETE", `/api/users/${u.id}`);
      await refreshAll();
    } catch (e) {
      console.error(e);
    }
  };

  const handleLogout = async () => {
    await logout();
    navigate("/login");
  };

  const handleExport = () => {
    const base = "__PORT_5000__".startsWith("__") ? "" : "__PORT_5000__";
    window.open(`${base}/api/records/export`, "_blank");
  };

  const stats = useMemo(() => {
    const byStatus: Record<string, number> = { yes: 0, no: 0, pending: 0 };
    for (const r of records) byStatus[r.approached] = (byStatus[r.approached] || 0) + 1;
    return byStatus;
  }, [records]);

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="border-b border-card-border bg-card/95 backdrop-blur sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 h-14 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link href="/map">
              <Button variant="ghost" size="sm" data-testid="link-back-to-map">
                <ArrowLeft className="w-4 h-4 mr-1.5" /> Map
              </Button>
            </Link>
            <div>
              <h1 className="font-semibold text-sm">Admin Panel</h1>
              <p className="text-[11px] text-muted-foreground">LagoonTrack</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-xs text-muted-foreground">
              Signed in as <span className="text-foreground font-medium">{user?.username}</span>
            </span>
            <Button variant="ghost" size="icon" onClick={handleLogout} data-testid="button-logout">
              <LogOut className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl w-full mx-auto px-6 py-8 flex-1">
        <Tabs defaultValue="users" className="space-y-6">
          <TabsList>
            <TabsTrigger value="users" data-testid="tab-users">Users</TabsTrigger>
            <TabsTrigger value="records" data-testid="tab-records">
              Records ({records.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="users" className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-semibold">Users & Territories</h2>
                <p className="text-sm text-muted-foreground">
                  Manage distributor accounts and assign US state territories.
                </p>
              </div>
              <Button onClick={openCreate} data-testid="button-add-user">
                <Plus className="w-4 h-4 mr-1.5" /> Add User
              </Button>
            </div>

            <div className="border border-card-border rounded-lg overflow-hidden bg-card">
              <table className="w-full text-sm">
                <thead className="bg-muted/50 text-xs uppercase tracking-wider text-muted-foreground">
                  <tr>
                    <th className="text-left px-4 py-3 font-medium">Username</th>
                    <th className="text-left px-4 py-3 font-medium">Role</th>
                    <th className="text-left px-4 py-3 font-medium">Distributor</th>
                    <th className="text-left px-4 py-3 font-medium">Territories</th>
                    <th className="text-right px-4 py-3 font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-card-border">
                  {loading ? (
                    <tr><td colSpan={5} className="text-center py-8 text-muted-foreground">Loading…</td></tr>
                  ) : users.length === 0 ? (
                    <tr><td colSpan={5} className="text-center py-8 text-muted-foreground">No users yet</td></tr>
                  ) : users.map(u => {
                    let terr: string[] = [];
                    try { terr = JSON.parse(u.territories || "[]"); } catch {}
                    return (
                      <tr key={u.id} data-testid={`row-user-${u.id}`}>
                        <td className="px-4 py-3 font-medium">{u.username}</td>
                        <td className="px-4 py-3">
                          <Badge variant={u.role === "admin" ? "default" : "secondary"}>
                            {u.role}
                          </Badge>
                        </td>
                        <td className="px-4 py-3 text-muted-foreground">{u.distributor || "—"}</td>
                        <td className="px-4 py-3">
                          {terr.length === 0 ? (
                            <span className="text-muted-foreground">—</span>
                          ) : (
                            <div className="flex flex-wrap gap-1">
                              {terr.map(t => (
                                <Badge key={t} variant="outline" className="font-mono text-[10px] px-1.5 py-0">
                                  {t}
                                </Badge>
                              ))}
                            </div>
                          )}
                        </td>
                        <td className="px-4 py-3 text-right">
                          <div className="inline-flex gap-1">
                            <Button
                              variant="ghost" size="icon"
                              onClick={() => openEdit(u)}
                              data-testid={`button-edit-user-${u.id}`}
                            >
                              <Pencil className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost" size="icon"
                              onClick={() => handleDelete(u)}
                              disabled={u.id === user?.id}
                              data-testid={`button-delete-user-${u.id}`}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </TabsContent>

          <TabsContent value="records" className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-semibold">Lagoon Records</h2>
                <p className="text-sm text-muted-foreground">
                  All distributor activity. {stats.yes || 0} approached · {stats.no || 0} declined · {stats.pending || 0} pending.
                </p>
              </div>
              <Button variant="outline" onClick={handleExport} data-testid="button-export-csv">
                Export CSV
              </Button>
            </div>

            <div className="border border-card-border rounded-lg overflow-hidden bg-card">
              <div className="max-h-[600px] overflow-y-auto">
                <table className="w-full text-sm">
                  <thead className="bg-muted/50 text-xs uppercase tracking-wider text-muted-foreground sticky top-0">
                    <tr>
                      <th className="text-left px-4 py-3 font-medium">Facility</th>
                      <th className="text-left px-4 py-3 font-medium">Status</th>
                      <th className="text-left px-4 py-3 font-medium">Distributor</th>
                      <th className="text-left px-4 py-3 font-medium">Note</th>
                      <th className="text-left px-4 py-3 font-medium">Updated By</th>
                      <th className="text-left px-4 py-3 font-medium">Updated At</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-card-border">
                    {records.length === 0 ? (
                      <tr><td colSpan={6} className="text-center py-8 text-muted-foreground">No records yet</td></tr>
                    ) : records.map(r => (
                      <tr key={r.id} data-testid={`row-record-${r.id}`}>
                        <td className="px-4 py-3 font-medium truncate max-w-[220px]" title={r.facilityName}>
                          {r.facilityName}
                        </td>
                        <td className="px-4 py-3">
                          <Badge
                            className={
                              r.approached === "yes" ? "bg-[#238636] hover:bg-[#238636] text-white" :
                              r.approached === "no"  ? "bg-[#da3633] hover:bg-[#da3633] text-white" :
                              ""
                            }
                            variant={r.approached === "pending" ? "outline" : undefined}
                          >
                            {r.approached === "yes" ? "Approached" : r.approached === "no" ? "Declined" : "Pending"}
                          </Badge>
                        </td>
                        <td className="px-4 py-3 text-muted-foreground">{r.distributor || "—"}</td>
                        <td className="px-4 py-3 text-muted-foreground truncate max-w-[260px]" title={r.note}>
                          {r.note || "—"}
                        </td>
                        <td className="px-4 py-3 text-muted-foreground">{r.updatedBy || "—"}</td>
                        <td className="px-4 py-3 text-muted-foreground text-[11px] font-mono">
                          {r.updatedAt ? new Date(r.updatedAt).toLocaleString() : "—"}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </main>

      {/* User dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingUser ? "Edit User" : "Add User"}</DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label htmlFor="f-username">Username</Label>
              <Input
                id="f-username"
                value={fUsername}
                onChange={e => setFUsername(e.target.value)}
                data-testid="input-form-username"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="f-password">
                Password {editingUser && <span className="text-muted-foreground text-xs">(leave blank to keep current)</span>}
              </Label>
              <Input
                id="f-password"
                type="password"
                value={fPassword}
                onChange={e => setFPassword(e.target.value)}
                data-testid="input-form-password"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="f-role">Role</Label>
              <Select value={fRole} onValueChange={v => setFRole(v as any)}>
                <SelectTrigger id="f-role" data-testid="select-form-role">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="admin">Admin</SelectItem>
                  <SelectItem value="distributor">Distributor</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {fRole === "distributor" && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="f-distributor">Distributor</Label>
                  <Select value={fDistributor || "__none__"} onValueChange={v => setFDistributor(v === "__none__" ? "" : v)}>
                    <SelectTrigger id="f-distributor" data-testid="select-form-distributor">
                      <SelectValue placeholder="Select distributor" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="__none__">— None —</SelectItem>
                      {DISTRIBUTORS.map(d => (
                        <SelectItem key={d} value={d}>{d}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Territories ({fTerritories.length} selected)</Label>
                  <div className="border border-border rounded-md p-3 max-h-56 overflow-y-auto grid grid-cols-3 sm:grid-cols-4 gap-1.5">
                    {ALL_STATES.map(s => {
                      const checked = fTerritories.includes(s);
                      return (
                        <label
                          key={s}
                          className="flex items-center gap-1.5 text-xs cursor-pointer hover:text-foreground text-muted-foreground"
                          title={STATE_NAMES[s]}
                        >
                          <Checkbox
                            checked={checked}
                            onCheckedChange={(v) => {
                              setFTerritories(prev =>
                                v ? [...prev, s] : prev.filter(x => x !== s)
                              );
                            }}
                            data-testid={`checkbox-state-${s}`}
                          />
                          <span className="font-mono">{s}</span>
                        </label>
                      );
                    })}
                  </div>
                </div>
              </>
            )}

            {error && (
              <div className="text-sm text-destructive bg-destructive/10 border border-destructive/30 rounded-md px-3 py-2">
                {error}
              </div>
            )}
          </div>

          <DialogFooter>
            <Button variant="ghost" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSubmit} disabled={saving} data-testid="button-form-save">
              {saving ? "Saving…" : editingUser ? "Save Changes" : "Create User"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <PerplexityAttribution />
    </div>
  );
}
