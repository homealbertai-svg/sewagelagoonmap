import { useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/App";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

function LagoonLogo({ size = 48 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 48 48"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-label="LagoonTrack"
    >
      {/* Droplet body */}
      <path
        d="M24 4 C 14 18, 8 26, 8 32 a 16 16 0 1 0 32 0 C 40 26, 34 18, 24 4 Z"
        fill="hsl(142 69% 30%)"
        stroke="hsl(142 69% 40%)"
        strokeWidth="1.5"
      />
      {/* Highlight */}
      <path
        d="M18 22 C 16 26, 16 30, 18 32"
        stroke="rgba(255,255,255,0.55)"
        strokeWidth="2"
        strokeLinecap="round"
        fill="none"
      />
      {/* Center dot — map pin reference */}
      <circle cx="24" cy="33" r="2.5" fill="white" />
    </svg>
  );
}

export default function LoginPage() {
  const { login, user } = useAuth();
  const [, navigate] = useLocation();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  if (user) {
    navigate("/map");
    return null;
  }

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      await login(username, password);
      navigate("/map");
    } catch (err: any) {
      const msg = String(err?.message || "Login failed");
      setError(msg.includes("401") ? "Invalid username or password" : msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-6">
      <div className="w-full max-w-sm">
        <div className="flex flex-col items-center gap-3 mb-8">
          <LagoonLogo size={56} />
          <div className="text-center">
            <h1 className="text-xl font-semibold tracking-tight">LagoonTrack</h1>
            <p className="text-sm text-muted-foreground mt-1">Distributor CRM</p>
          </div>
        </div>

        <form
          onSubmit={onSubmit}
          className="bg-card border border-card-border rounded-lg p-6 shadow-lg space-y-4"
          data-testid="form-login"
        >
          <div className="space-y-2">
            <Label htmlFor="username">Username</Label>
            <Input
              id="username"
              type="text"
              autoComplete="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
              data-testid="input-username"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <Input
              id="password"
              type="password"
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              data-testid="input-password"
            />
          </div>

          {error && (
            <div
              className="text-sm text-destructive bg-destructive/10 border border-destructive/30 rounded-md px-3 py-2"
              data-testid="text-error"
            >
              {error}
            </div>
          )}

          <Button
            type="submit"
            className="w-full"
            disabled={loading}
            data-testid="button-sign-in"
          >
            {loading ? "Signing in…" : "Sign In"}
          </Button>
        </form>

        <p className="text-xs text-center text-muted-foreground mt-6">
          Accounts are managed by your administrator.
        </p>
      </div>
    </div>
  );
}
