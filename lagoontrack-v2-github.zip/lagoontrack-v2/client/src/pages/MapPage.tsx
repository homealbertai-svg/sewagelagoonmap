import { useEffect, useMemo, useRef, useState } from "react";
import { useLocation, Link } from "wouter";
import { useAuth } from "@/App";
import { apiRequest } from "@/lib/queryClient";
import { getLagoonState, STATE_NAMES } from "@/lib/states";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue
} from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Badge } from "@/components/ui/badge";
import { Sun, Moon, LogOut, Settings, X, MapPin } from "lucide-react";
import PerplexityAttribution from "@/components/PerplexityAttribution";

type Lagoon = { name: string; lat: number; lng: number };
type LagoonRecord = {
  id?: number;
  facilityName: string;
  approached: "yes" | "no" | "pending";
  distributor: string;
  note: string;
  updatedBy: string;
  updatedAt: string;
};

const DISTRIBUTORS = ["CC Lynch", "GeoTech", "Eijkelkamp USA"];

function LogoSmall() {
  return (
    <svg width="28" height="28" viewBox="0 0 48 48" fill="none" aria-label="LagoonTrack">
      <path
        d="M24 4 C 14 18, 8 26, 8 32 a 16 16 0 1 0 32 0 C 40 26, 34 18, 24 4 Z"
        fill="hsl(142 69% 30%)"
        stroke="hsl(142 69% 40%)"
        strokeWidth="1.5"
      />
      <circle cx="24" cy="33" r="2.5" fill="white" />
    </svg>
  );
}

function colorForApproached(a: string) {
  if (a === "yes") return "#238636";
  if (a === "no") return "#da3633";
  return "#6e7681";
}

function markerHtml(color: string) {
  return `<div class="lagoon-marker" style="background:${color};width:14px;height:14px;"></div>`;
}

export default function MapPage() {
  const { user, logout } = useAuth();
  const [, navigate] = useLocation();

  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<any>(null);
  const clusterGroupRef = useRef<any>(null);
  const tileLayerRef = useRef<any>(null);

  const [records, setRecords] = useState<Record<string, LagoonRecord>>({});
  const [lagoonsLoaded, setLagoonsLoaded] = useState<boolean>(
    Array.isArray((window as any).LAGOONS) && (window as any).LAGOONS.length > 0
  );
  const [activeFilter, setActiveFilter] = useState<"all" | "yes" | "no" | "pending">("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [isDark, setIsDark] = useState(true);
  const [selectedLagoon, setSelectedLagoon] = useState<Lagoon | null>(null);

  // Form state for side panel
  const [formApproached, setFormApproached] = useState<"yes" | "no" | "pending">("pending");
  const [formDistributor, setFormDistributor] = useState<string>("");
  const [formNote, setFormNote] = useState<string>("");
  const [saving, setSaving] = useState(false);

  // Dark mode toggle effect
  useEffect(() => {
    document.documentElement.classList.toggle("dark", isDark);
  }, [isDark]);

  // Fetch records
  useEffect(() => {
    (async () => {
      try {
        const res = await apiRequest("GET", "/api/records");
        const data: LagoonRecord[] = await res.json();
        const map: Record<string, LagoonRecord> = {};
        for (const r of data) map[r.facilityName] = r;
        setRecords(map);
      } catch (e) {
        // ignore
      }
    })();
  }, []);

  // Fall back to /api/lagoons if not inlined (e.g., dev mode)
  useEffect(() => {
    if (lagoonsLoaded) return;
    const w = window as any;
    if (Array.isArray(w.LAGOONS) && w.LAGOONS.length > 0) {
      setLagoonsLoaded(true);
      return;
    }
    (async () => {
      try {
        const base = "__PORT_5000__".startsWith("__") ? "" : "__PORT_5000__";
        const res = await fetch(`${base}/api/lagoons`, { credentials: "include" });
        const data = await res.json();
        w.LAGOONS = data;
        setLagoonsLoaded(true);
      } catch (e) {
        console.error("Failed to load lagoons:", e);
      }
    })();
  }, [lagoonsLoaded]);

  // Compute user's territories
  const userTerritories: string[] = useMemo(() => {
    if (!user) return [];
    try { return JSON.parse(user.territories || "[]"); } catch { return []; }
  }, [user]);

  // Visible lagoons based on territory + filter + search
  const visibleLagoons = useMemo<Lagoon[]>(() => {
    if (!lagoonsLoaded) return [];
    const all: Lagoon[] = (window as any).LAGOONS || [];
    const isAdmin = user?.role === "admin";

    let list = all;
    if (!isAdmin && userTerritories.length > 0) {
      list = all.filter(l => {
        const s = getLagoonState(l.lat, l.lng);
        return s && userTerritories.includes(s);
      });
    } else if (!isAdmin && userTerritories.length === 0) {
      list = []; // distributor with no territory sees nothing
    }

    if (searchQuery.trim()) {
      const q = searchQuery.trim().toLowerCase();
      list = list.filter(l => l.name.toLowerCase().includes(q));
    }

    if (activeFilter !== "all") {
      list = list.filter(l => {
        const r = records[l.name];
        const status = r?.approached || "pending";
        return status === activeFilter;
      });
    }

    return list;
  }, [user, userTerritories, records, activeFilter, searchQuery, lagoonsLoaded]);

  // Stats
  const stats = useMemo(() => {
    if (!lagoonsLoaded) return { total: 0, yes: 0, no: 0, pending: 0 };
    const all: Lagoon[] = (window as any).LAGOONS || [];
    const isAdmin = user?.role === "admin";
    const base = isAdmin
      ? all
      : all.filter(l => {
          const s = getLagoonState(l.lat, l.lng);
          return s && userTerritories.includes(s);
        });
    let yes = 0, no = 0, pending = 0;
    for (const l of base) {
      const status = records[l.name]?.approached || "pending";
      if (status === "yes") yes++;
      else if (status === "no") no++;
      else pending++;
    }
    return { total: base.length, yes, no, pending };
  }, [user, userTerritories, records, lagoonsLoaded]);

  // Initialize map once
  useEffect(() => {
    if (!mapRef.current || mapInstanceRef.current) return;
    const L = (window as any).L;
    if (!L) return;

    const map = L.map(mapRef.current, {
      center: [39.5, -98.35],
      zoom: 4,
      worldCopyJump: true,
      preferCanvas: true,
    });

    const tile = L.tileLayer(
      isDark
        ? "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
        : "https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png",
      {
        attribution: '&copy; OpenStreetMap &copy; CARTO',
        maxZoom: 19,
      }
    );
    tile.addTo(map);
    tileLayerRef.current = tile;

    const cluster = L.markerClusterGroup({
      chunkedLoading: true,
      spiderfyOnMaxZoom: true,
      showCoverageOnHover: false,
      maxClusterRadius: 50,
    });
    map.addLayer(cluster);

    mapInstanceRef.current = map;
    clusterGroupRef.current = cluster;

    // Fit to user's territory if any
    setTimeout(() => map.invalidateSize(), 100);
  }, []); // eslint-disable-line

  // Swap tile layer when theme changes
  useEffect(() => {
    const L = (window as any).L;
    const map = mapInstanceRef.current;
    if (!L || !map) return;
    if (tileLayerRef.current) map.removeLayer(tileLayerRef.current);
    const tile = L.tileLayer(
      isDark
        ? "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
        : "https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png",
      { attribution: '&copy; OpenStreetMap &copy; CARTO', maxZoom: 19 }
    );
    tile.addTo(map);
    tileLayerRef.current = tile;
  }, [isDark]);

  // Update markers when visibleLagoons or records change
  useEffect(() => {
    const L = (window as any).L;
    const cluster = clusterGroupRef.current;
    if (!L || !cluster) return;

    cluster.clearLayers();

    const markers = visibleLagoons.map(l => {
      const record = records[l.name];
      const status = record?.approached || "pending";
      const color = colorForApproached(status);
      const icon = L.divIcon({
        className: "",
        html: markerHtml(color),
        iconSize: [14, 14],
        iconAnchor: [7, 7],
      });
      const m = L.marker([l.lat, l.lng], { icon });
      m.bindTooltip(l.name, { direction: "top", offset: [0, -6] });
      m.on("click", () => {
        setSelectedLagoon(l);
      });
      return m;
    });

    cluster.addLayers(markers);
  }, [visibleLagoons, records]);

  // When opening side panel, sync form values
  useEffect(() => {
    if (!selectedLagoon) return;
    const r = records[selectedLagoon.name];
    setFormApproached(r?.approached || "pending");
    setFormDistributor(r?.distributor || user?.distributor || "");
    setFormNote(r?.note || "");
  }, [selectedLagoon, records, user]);

  const handleSave = async () => {
    if (!selectedLagoon || !user) return;
    setSaving(true);
    try {
      const payload = {
        facilityName: selectedLagoon.name,
        approached: formApproached,
        distributor: formDistributor,
        note: formNote,
        updatedBy: user.username,
        updatedAt: new Date().toISOString(),
      };
      const res = await apiRequest("POST", "/api/records/upsert", payload);
      const saved: LagoonRecord = await res.json();
      setRecords(prev => ({ ...prev, [saved.facilityName]: saved }));
    } catch (e) {
      console.error(e);
    } finally {
      setSaving(false);
    }
  };

  const handleLogout = async () => {
    await logout();
    navigate("/login");
  };

  const handleExport = async () => {
    const base = "__PORT_5000__".startsWith("__") ? "" : "__PORT_5000__";
    window.open(`${base}/api/records/export`, "_blank");
  };

  const filters: { key: typeof activeFilter; label: string; dotColor: string }[] = [
    { key: "all", label: "All", dotColor: "transparent" },
    { key: "yes", label: "Approached", dotColor: "#238636" },
    { key: "no", label: "Declined", dotColor: "#da3633" },
    { key: "pending", label: "Pending", dotColor: "#6e7681" },
  ];

  return (
    <div className="h-screen w-screen flex flex-col overflow-hidden">
      {/* Header */}
      <header className="border-b border-card-border bg-card/95 backdrop-blur z-[1000] shadow-sm">
        <div className="flex items-center justify-between gap-3 px-4 h-14">
          <div className="flex items-center gap-3 min-w-0 shrink-0">
            <LogoSmall />
            <div className="hidden sm:flex flex-col leading-tight">
              <span className="font-semibold text-sm">LagoonTrack</span>
              <span className="text-[11px] text-muted-foreground">Distributor CRM</span>
            </div>
          </div>

          <div className="hidden 2xl:flex items-center gap-2 shrink-0">
            <Badge variant="secondary" className="font-mono" data-testid="badge-total">
              {stats.total.toLocaleString()} total
            </Badge>
            <Badge className="bg-[#238636] hover:bg-[#238636] text-white" data-testid="badge-approached">
              {stats.yes} approached
            </Badge>
            <Badge className="bg-[#da3633] hover:bg-[#da3633] text-white" data-testid="badge-declined">
              {stats.no} declined
            </Badge>
            <Badge variant="outline" data-testid="badge-pending">
              {stats.pending} pending
            </Badge>
          </div>

          <div className="flex items-center gap-2 flex-1 justify-end min-w-0">
            <Input
              type="search"
              placeholder="Search facilities…"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-40 md:w-56 h-9 shrink-0"
              data-testid="input-search"
            />

            <div className="hidden md:flex items-center gap-1 bg-muted/50 rounded-md p-0.5 shrink-0">
              {filters.map(f => (
                <button
                  key={f.key}
                  onClick={() => setActiveFilter(f.key)}
                  className={`flex items-center gap-1.5 px-2.5 h-8 text-xs rounded transition-colors ${
                    activeFilter === f.key
                      ? "bg-primary text-primary-foreground"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                  data-testid={`button-filter-${f.key}`}
                >
                  {f.dotColor !== "transparent" && (
                    <span
                      className="w-2 h-2 rounded-full"
                      style={{ background: f.dotColor }}
                    />
                  )}
                  {f.label}
                </button>
              ))}
            </div>

            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsDark(d => !d)}
              data-testid="button-theme-toggle"
              aria-label="Toggle theme"
            >
              {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </Button>

            <Button
              variant="outline"
              size="sm"
              onClick={handleExport}
              data-testid="button-export"
              className="hidden xl:flex shrink-0"
            >
              Export CSV
            </Button>

            {user?.role === "admin" && (
              <Link href="/admin">
                <Button variant="outline" size="sm" data-testid="link-admin">
                  <Settings className="w-4 h-4 mr-1.5" /> Admin
                </Button>
              </Link>
            )}

            <div className="hidden xl:flex flex-col items-end leading-tight text-right px-2 shrink-0">
              <span className="text-xs font-medium" data-testid="text-username">{user?.username}</span>
              <span className="text-[10px] text-muted-foreground">
                {user?.role === "admin"
                  ? "Administrator"
                  : `${user?.distributor || "Distributor"} · ${userTerritories.length ? userTerritories.join(", ") : "No territory"}`}
              </span>
            </div>

            <Button
              variant="ghost"
              size="icon"
              onClick={handleLogout}
              data-testid="button-logout"
              aria-label="Sign out"
            >
              <LogOut className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {user?.role !== "admin" && userTerritories.length > 0 && (
          <div className="px-4 pb-2 -mt-1 flex flex-wrap items-center gap-1.5 text-xs text-muted-foreground">
            <MapPin className="w-3.5 h-3.5" />
            <span>Territory:</span>
            {userTerritories.map(t => (
              <Badge key={t} variant="outline" className="font-mono text-[10px] px-1.5 py-0">
                {t}
              </Badge>
            ))}
          </div>
        )}
      </header>

      {/* Map */}
      <div className="relative flex-1">
        <div ref={mapRef} className="absolute inset-0" data-testid="map-container" />

        {user?.role !== "admin" && userTerritories.length === 0 && (
          <div className="absolute inset-0 flex items-center justify-center bg-background/80 backdrop-blur z-[500]">
            <div className="max-w-md text-center p-8 bg-card border border-card-border rounded-lg shadow-lg">
              <MapPin className="w-8 h-8 mx-auto mb-3 text-muted-foreground" />
              <h2 className="text-lg font-semibold mb-1">No territory assigned</h2>
              <p className="text-sm text-muted-foreground">
                Your administrator hasn't assigned you a sales territory yet.
                Once they do, lagoons in your assigned states will appear here.
              </p>
            </div>
          </div>
        )}

        {/* Side panel */}
        {selectedLagoon && (
          <div
            className="absolute top-0 right-0 h-full w-full sm:w-[380px] bg-card border-l border-card-border shadow-2xl z-[1000] flex flex-col"
            data-testid="panel-edit"
          >
            <div className="flex items-start justify-between px-5 py-4 border-b border-card-border">
              <div className="min-w-0 pr-3">
                <h3 className="font-semibold text-sm truncate" data-testid="text-facility-name">
                  {selectedLagoon.name}
                </h3>
                <p className="text-[11px] text-muted-foreground mt-0.5 font-mono">
                  {selectedLagoon.lat.toFixed(4)}, {selectedLagoon.lng.toFixed(4)}
                  {(() => {
                    const s = getLagoonState(selectedLagoon.lat, selectedLagoon.lng);
                    return s ? ` · ${STATE_NAMES[s] || s}` : "";
                  })()}
                </p>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setSelectedLagoon(null)}
                data-testid="button-close-panel"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>

            <div className="flex-1 overflow-y-auto px-5 py-4 space-y-5">
              <div>
                <Label className="mb-2 block">Approached</Label>
                <RadioGroup
                  value={formApproached}
                  onValueChange={(v) => setFormApproached(v as any)}
                  className="grid grid-cols-3 gap-2"
                >
                  {(["yes", "no", "pending"] as const).map(opt => (
                    <label
                      key={opt}
                      className={`flex items-center justify-center gap-1.5 px-2 h-9 rounded-md border cursor-pointer text-xs capitalize ${
                        formApproached === opt
                          ? "bg-primary/10 border-primary text-foreground"
                          : "border-border text-muted-foreground hover:text-foreground"
                      }`}
                    >
                      <RadioGroupItem value={opt} className="sr-only" />
                      <span
                        className="w-2 h-2 rounded-full"
                        style={{ background: colorForApproached(opt) }}
                      />
                      {opt === "yes" ? "Approached" : opt === "no" ? "Declined" : "Pending"}
                    </label>
                  ))}
                </RadioGroup>
              </div>

              <div>
                <Label htmlFor="distributor" className="mb-2 block">Distributor</Label>
                <Select value={formDistributor || "__none__"} onValueChange={v => setFormDistributor(v === "__none__" ? "" : v)}>
                  <SelectTrigger id="distributor" data-testid="select-distributor">
                    <SelectValue placeholder="Select distributor" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="__none__">— None —</SelectItem>
                    {DISTRIBUTORS.map(d => (
                      <SelectItem key={d} value={d}>{d}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="note" className="mb-2 block">Notes</Label>
                <Textarea
                  id="note"
                  value={formNote}
                  onChange={e => setFormNote(e.target.value)}
                  rows={6}
                  placeholder="Add contact notes, next steps, contact name…"
                  data-testid="textarea-note"
                />
              </div>

              {records[selectedLagoon.name] && (
                <div className="text-[11px] text-muted-foreground border-t border-card-border pt-3">
                  Last updated by{" "}
                  <span className="text-foreground font-medium">
                    {records[selectedLagoon.name].updatedBy || "—"}
                  </span>
                  {records[selectedLagoon.name].updatedAt && (
                    <> on {new Date(records[selectedLagoon.name].updatedAt).toLocaleString()}</>
                  )}
                </div>
              )}
            </div>

            <div className="px-5 py-4 border-t border-card-border flex gap-2">
              <Button
                variant="ghost"
                onClick={() => setSelectedLagoon(null)}
                className="flex-1"
                data-testid="button-cancel"
              >
                Cancel
              </Button>
              <Button
                onClick={handleSave}
                disabled={saving}
                className="flex-1"
                data-testid="button-save"
              >
                {saving ? "Saving…" : "Save"}
              </Button>
            </div>
          </div>
        )}
      </div>
      <PerplexityAttribution />
    </div>
  );
}
