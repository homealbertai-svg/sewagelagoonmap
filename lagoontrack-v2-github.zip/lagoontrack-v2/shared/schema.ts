import { sqliteTable, text, integer } from "drizzle-orm/sqlite-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table
export const users = sqliteTable("users", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  username: text("username").notNull().unique(),
  password: text("password").notNull(), // bcrypt hash
  role: text("role").notNull().default("distributor"), // "admin" | "distributor"
  distributor: text("distributor").notNull().default(""), // "CC Lynch" | "GeoTech" | "Eijkelkamp USA"
  territories: text("territories").notNull().default("[]"), // JSON array of US state abbreviations
});

export const insertUserSchema = createInsertSchema(users).omit({ id: true });
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Lagoon tracking records
export const lagoonRecords = sqliteTable("lagoon_records", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  facilityName: text("facility_name").notNull().unique(),
  approached: text("approached").notNull().default("pending"), // "yes" | "no" | "pending"
  distributor: text("distributor").notNull().default(""),
  note: text("note").notNull().default(""),
  updatedBy: text("updated_by").notNull().default(""),
  updatedAt: text("updated_at").notNull().default(""),
});

export const insertLagoonRecordSchema = createInsertSchema(lagoonRecords).omit({ id: true });
export type InsertLagoonRecord = z.infer<typeof insertLagoonRecordSchema>;
export type LagoonRecord = typeof lagoonRecords.$inferSelect;
