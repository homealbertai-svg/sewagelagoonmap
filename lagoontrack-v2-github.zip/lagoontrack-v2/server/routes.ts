import type { Express, Request, Response, NextFunction } from "express";
import type { Server } from "node:http";
import bcrypt from "bcryptjs";
import fs from "node:fs";
import path from "node:path";
import { storage } from "./storage";
import { insertUserSchema } from "@shared/schema";
import { z } from "zod";

function requireAuth(req: Request, res: Response, next: NextFunction) {
  if (!req.session.userId) return res.status(401).json({ error: "Unauthorized" });
  next();
}

function requireAdmin(req: Request, res: Response, next: NextFunction) {
  if (!req.session.userId || req.session.role !== "admin") {
    return res.status(403).json({ error: "Forbidden" });
  }
  next();
}

function publicUser(u: any) {
  return {
    id: u.id,
    username: u.username,
    role: u.role,
    distributor: u.distributor,
    territories: u.territories, // JSON string — frontend parses
  };
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Serve lagoons data (used in dev; production inlines into index.html)
  app.get("/api/lagoons", (_req, res) => {
    try {
      const p = path.resolve("/home/user/workspace/lagoons.json");
      const data = fs.readFileSync(p, "utf-8");
      res.setHeader("Content-Type", "application/json");
      res.send(data);
    } catch (e) {
      res.status(500).json({ error: "Could not load lagoons" });
    }
  });

  // ===== Auth =====
  app.post("/api/auth/login", (req, res) => {
    const { username, password } = req.body || {};
    if (!username || !password) {
      return res.status(400).json({ error: "Missing credentials" });
    }
    const user = storage.getUserByUsername(username);
    if (!user || !bcrypt.compareSync(password, user.password)) {
      return res.status(401).json({ error: "Invalid username or password" });
    }
    req.session.userId = user.id;
    req.session.role = user.role;
    req.session.username = user.username;
    res.json(publicUser(user));
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy(() => {
      res.json({ ok: true });
    });
  });

  app.get("/api/auth/me", (req, res) => {
    if (!req.session.userId) return res.status(401).json({ error: "Unauthorized" });
    const user = storage.getUser(req.session.userId);
    if (!user) return res.status(401).json({ error: "Unauthorized" });
    res.json(publicUser(user));
  });

  // ===== User management (admin) =====
  app.get("/api/users", requireAdmin, (_req, res) => {
    const list = storage.getAllUsers().map(publicUser);
    res.json(list);
  });

  app.post("/api/users", requireAdmin, (req, res) => {
    try {
      const body = req.body || {};
      const data = insertUserSchema.parse({
        username: body.username,
        password: bcrypt.hashSync(body.password || "changeme", 10),
        role: body.role || "distributor",
        distributor: body.distributor || "",
        territories: typeof body.territories === "string"
          ? body.territories
          : JSON.stringify(body.territories || []),
      });
      const existing = storage.getUserByUsername(data.username);
      if (existing) return res.status(400).json({ error: "Username already exists" });
      const created = storage.createUser(data);
      res.json(publicUser(created));
    } catch (e: any) {
      res.status(400).json({ error: e.message || "Invalid data" });
    }
  });

  app.put("/api/users/:id", requireAdmin, (req, res) => {
    const id = parseInt(req.params.id, 10);
    const body = req.body || {};
    const patch: any = {};
    if (body.username !== undefined) patch.username = body.username;
    if (body.password) patch.password = bcrypt.hashSync(body.password, 10);
    if (body.role !== undefined) patch.role = body.role;
    if (body.distributor !== undefined) patch.distributor = body.distributor;
    if (body.territories !== undefined) {
      patch.territories = typeof body.territories === "string"
        ? body.territories
        : JSON.stringify(body.territories);
    }
    const updated = storage.updateUser(id, patch);
    if (!updated) return res.status(404).json({ error: "Not found" });
    res.json(publicUser(updated));
  });

  app.delete("/api/users/:id", requireAdmin, (req, res) => {
    const id = parseInt(req.params.id, 10);
    if (id === req.session.userId) {
      return res.status(400).json({ error: "Cannot delete your own account" });
    }
    storage.deleteUser(id);
    res.json({ ok: true });
  });

  // ===== Lagoon records =====
  const upsertSchema = z.object({
    facilityName: z.string().min(1),
    approached: z.enum(["yes", "no", "pending"]).default("pending"),
    distributor: z.string().default(""),
    note: z.string().default(""),
    updatedBy: z.string().default(""),
    updatedAt: z.string().default(""),
  });

  app.get("/api/records", requireAuth, (_req, res) => {
    // Return all; client filters visible markers by territory.
    // (We don't know each lagoon's state on the server without lat/lng map.)
    res.json(storage.getAllLagoonRecords());
  });

  app.post("/api/records/upsert", requireAuth, (req, res) => {
    try {
      const data = upsertSchema.parse(req.body);
      const username = req.session.username || "";
      const record = storage.upsertLagoonRecord({
        ...data,
        updatedBy: data.updatedBy || username,
        updatedAt: data.updatedAt || new Date().toISOString(),
      });
      res.json(record);
    } catch (e: any) {
      res.status(400).json({ error: e.message || "Invalid data" });
    }
  });

  app.get("/api/records/export", requireAuth, (_req, res) => {
    const records = storage.getAllLagoonRecords();
    const header = "Facility Name,Approached,Distributor,Note,Updated By,Updated At\n";
    const escape = (s: string) => `"${(s || "").replace(/"/g, '""')}"`;
    const rows = records.map(r =>
      [r.facilityName, r.approached, r.distributor, r.note, r.updatedBy, r.updatedAt]
        .map(escape).join(",")
    ).join("\n");
    res.setHeader("Content-Type", "text/csv");
    res.setHeader("Content-Disposition", 'attachment; filename="lagoon-records.csv"');
    res.send(header + rows);
  });

  return httpServer;
}
