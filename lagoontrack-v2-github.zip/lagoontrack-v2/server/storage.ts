import { users, lagoonRecords } from '@shared/schema';
import type { User, InsertUser, LagoonRecord, InsertLagoonRecord } from '@shared/schema';
import { drizzle } from "drizzle-orm/better-sqlite3";
import Database from "better-sqlite3";
import { eq } from "drizzle-orm";
import bcrypt from "bcryptjs";
import fs from "node:fs";

// Make sure db dir exists
fs.mkdirSync("./db", { recursive: true });

const sqlite = new Database("./db/data.db");
sqlite.pragma("journal_mode = WAL");

// Create tables if they don't exist
sqlite.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'distributor',
    distributor TEXT NOT NULL DEFAULT '',
    territories TEXT NOT NULL DEFAULT '[]'
  );
  CREATE TABLE IF NOT EXISTS lagoon_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    facility_name TEXT NOT NULL UNIQUE,
    approached TEXT NOT NULL DEFAULT 'pending',
    distributor TEXT NOT NULL DEFAULT '',
    note TEXT NOT NULL DEFAULT '',
    updated_by TEXT NOT NULL DEFAULT '',
    updated_at TEXT NOT NULL DEFAULT ''
  );
`);

export const db = drizzle(sqlite);

export interface IStorage {
  getUser(id: number): User | undefined;
  getUserByUsername(username: string): User | undefined;
  getAllUsers(): User[];
  createUser(user: InsertUser): User;
  updateUser(id: number, data: Partial<InsertUser>): User | undefined;
  deleteUser(id: number): void;

  getLagoonRecord(facilityName: string): LagoonRecord | undefined;
  getAllLagoonRecords(): LagoonRecord[];
  upsertLagoonRecord(record: Omit<InsertLagoonRecord, 'id'>): LagoonRecord;
}

export class DatabaseStorage implements IStorage {
  getUser(id: number): User | undefined {
    return db.select().from(users).where(eq(users.id, id)).get();
  }

  getUserByUsername(username: string): User | undefined {
    return db.select().from(users).where(eq(users.username, username)).get();
  }

  getAllUsers(): User[] {
    return db.select().from(users).all();
  }

  createUser(insertUser: InsertUser): User {
    return db.insert(users).values(insertUser).returning().get();
  }

  updateUser(id: number, data: Partial<InsertUser>): User | undefined {
    if (Object.keys(data).length === 0) return this.getUser(id);
    return db.update(users).set(data).where(eq(users.id, id)).returning().get();
  }

  deleteUser(id: number): void {
    db.delete(users).where(eq(users.id, id)).run();
  }

  getLagoonRecord(facilityName: string): LagoonRecord | undefined {
    return db.select().from(lagoonRecords).where(eq(lagoonRecords.facilityName, facilityName)).get();
  }

  getAllLagoonRecords(): LagoonRecord[] {
    return db.select().from(lagoonRecords).all();
  }

  upsertLagoonRecord(record: Omit<InsertLagoonRecord, 'id'>): LagoonRecord {
    const existing = this.getLagoonRecord(record.facilityName);
    if (existing) {
      return db.update(lagoonRecords).set(record).where(eq(lagoonRecords.facilityName, record.facilityName)).returning().get();
    }
    return db.insert(lagoonRecords).values(record).returning().get();
  }
}

export const storage = new DatabaseStorage();

// Seed admin user if none exists
const existingAdmin = storage.getUserByUsername("admin");
if (!existingAdmin) {
  storage.createUser({
    username: "admin",
    password: bcrypt.hashSync("admin123", 10),
    role: "admin",
    distributor: "",
    territories: "[]",
  });
  console.log("Seeded default admin user (username: admin, password: admin123)");
}
